import React, { useState } from 'react';
import { Text, View, StyleSheet,TouchableOpacity, Button } from 'react-native';

import { Card } from 'react-native-paper';

export default function App() {

const [count, setCount] = useState(0);


  function counter(incrementar) {
    if(incrementar){
      setCount(count+1);
    }else{
      if(count > 0){
        setCount(count-1);
      }
    }
  }


  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Contador
      </Text>

      <Card style={{marginTop: 12, padding:8, background: "#e9e9e9", border: "2px solid #ccc"}}>
      <Text style={{ fontSize: 16}}>{count}</Text>
      </Card>

      <Card style={{marginTop: 12, padding:2, background: "#e9e9e9", border: "2px solid #ccc"}}>
        <TouchableOpacity style={[styles.button, { backgroundColor: 'green'}]} onPress={() => counter(true)} >
          <Text style={styles.buttonText}>Adicionar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.button, { backgroundColor: 'red', marginTop:12}]} onPress={() => counter(false)} >
          <Text style={styles.buttonText}>Remover</Text>
        </TouchableOpacity>
            </Card>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginTop: 24,
  },
  paragraph: {
    borderRadius: 12,
    margin: 24,
    fontSize: 28,
    padding:16,
    backgroundColor: "#202020",
    color: "#22ffff",
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonText: {
    textTransform: 'uppercase',
    padding: 8,
    textAlign: 'center',
    color: 'white',
    fontWeight: '600',
  },
});
