import React, { Component, useState } from 'react';
import { View, StyleSheet, FlatList, Text } from 'react-native';
import { styles } from './styles';



function App(){


  let initial_feed = [
        {id: 1, titulo: 'Desenvolvedor Frontend', salario: 'R$ 3000,00', descri: 'Desenvolver páginas web com html, css e javascript.', contato: '(13)98866-5544'},
        {id: 2, titulo: 'Desenvolvedor Backend', salario: 'R$ 3500,00', descri: 'Desenvolver backend com Java e .Net', contato: '(13)97744-8844'},
        {id: 3, titulo: 'Engenheiro de Dados', salario: 'R$ 5000,00', descri: 'Engenhero de dados com Python', contato: '(13)96677-1122'},
        {id: 4, titulo: 'Engenheiro de Software', salario: 'R$ 5000,00', descri: 'Engenheiro de software utilizando conceitos RUP', contato: '(13)99922-7733'},
      ]


  const [feed, setFeed] = useState(initial_feed)


  return(
    <View style={styles.backg}>

      <Text style={styles.titulo}>Vagas</Text>

      <FlatList
      data={feed}
      keyExtractor={(item) => item.id}
      renderItem={ ({item}) => <Pessoa data={item}/>}
      />
    </View>
  )
}

export default App;

function Pessoa(props){
  return(
      <View style={styles.areaPessoa}>
        <Text style={styles.texto}>{props.data.titulo} </Text>
        <Text style={styles.textoPessoa}>Salario: {props.data.salario} </Text>
        <Text style={styles.textoPessoa}>Descrição: {props.data.descri} </Text>
        <Text style={styles.textoPessoa}>Contato: {props.data.contato} </Text>
      </View>
  );
}
