import {StyleSheet} from 'react-native'


const styles = StyleSheet.create({
  backg:{
    margin: 5,
    borderWidth: 2,
    borderColor: '#777',
    borderRadius: 50,
    paddingBottom: 50,
    paddingRight: 10,
    paddingLeft: 10,
    backgroundColor: '#efe',
  },

  titulo:{
    fontSize: 20,
    color:'green',
    marginTop: 55,
    textAlign: 'center',
  },
  
  texto:{
    fontSize: 16,
    color:'gray',
    marginTop: 5,
    marginLeft: 10
  },

  resultado: {
    fontSize: 20,
    textAlign: 'center',
    color: 'green',
    padding: 10
  },
  
  input:{
    height: 32,
    borderWidth: 1,
    borderColor: '#999',
    margin: 8,
    fontSize: 20,
    padding: 10,
    backgroundColor: '#eff',
  },

  picked:{
    marginLeft: 10,
    marginRight: 60,
    borderWidth: 2,
    borderColor: '#999',
    backgroundColor: '#eff',
  },

  slide:{
    marginLeft: 10,
    marginRight: 60
  },

  textoResult:{
    fontSize: 16,
    color:'#222',
    marginTop: 5,
    marginLeft: 10
  },

})

export {styles}