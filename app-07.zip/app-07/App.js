import { useState } from 'react';
import { View, Text, Button, TextInput, Switch, Picker } from 'react-native';
import { styles } from './styles';
import Slider from '@react-native-community/slider';

export default function App() {
  let escolaridade_inicial = [
    { id: 1, name: 'Fundamental Incompleto' },
    { id: 2, name: 'Fundamental' },
    { id: 3, name: 'Médio Incompleto' },
    { id: 4, name: 'Médio' },
    { id: 5, name: 'Superior Incompleto' },
    { id: 6, name: 'Superior' },
    { id: 7, name: 'Pós-Graduação' },
    { id: 8, name: 'Mestrado' },
  ];

  const [sexo, setSexo] = useState('masculino');
  const [escolaridade, setEscolaridade] = useState(0);
  const [escolaridades, setEscolaridades] = useState(escolaridade_inicial);
  const [nome, setNome] = useState('');
  const [idade, setIdade] = useState('');
  const [valor, setValor] = useState(0);
  const [status, setStatus] = useState(false);
  const [result, setResult] = useState('');

  let escolaridadeItem = escolaridades.map((valor, chave) => {
    return <Picker.Item key={chave} value={valor.id} label={valor.name} />;
  });

  function Confirmar() {
    var std = '';
    var br = status ? 'Brasileiro' : 'Estrangeiro';
    std += '\nDados Informados: \n \n';
    std += 'Nome: ' + nome + '\n';
    std += 'Idade: ' + idade + '\n';
    std += 'Sexo: ' + sexo + '\n';
    std += 'Escolaridade: ' + escolaridades[escolaridade].name + '\n';
    std += 'Limite: ' + valor.toFixed(0) + '\n';
    std += 'Nacionalidade: ' + br + '\n';
    setResult(std);
  }

  function pegaNome(texto) {
    if (texto.length > 0) {
      setNome(texto);
    }
  }

  function pegaIdade(texto) {
    if (texto.length > 0) {
      setIdade(texto);
    }
  }

  return (
    <View style={styles.backg}>
      <Text style={styles.titulo}>Abertura de Conta</Text>

      <Text style={styles.texto}>Nome</Text>

      <TextInput style={styles.input} onChangeText={pegaNome} />

      <Text style={styles.texto}>Idade</Text>

      <TextInput style={styles.input} onChangeText={pegaIdade} />

      <Text style={styles.texto}>Sexo</Text>

      <Picker
        style={styles.picked}
        selectedValue={sexo}
        onValueChange={(itemValue, itemIndex) => setSexo(itemValue)}>
        <Picker.Item key={1} value="Masculino" label="Masculino" />
        <Picker.Item key={2} value="Feminino" label="Feminino" />
      </Picker>

      <Text style={styles.texto}>Escolaridade</Text>

      <Picker
        style={styles.picked}
        selectedValue={escolaridade + 1}
        onValueChange={(itemValue, itemIndex) => setEscolaridade(itemIndex)}>
        {escolaridadeItem}
      </Picker>

      <Text style={styles.texto}>Limite</Text>

      <Slider
        style={styles.slide}
        minimumValue={0}
        maximumValue={200}
        onValueChange={(valorSelecionado) => setValor(valorSelecionado)}
        value={valor}
        step={1}
        minimumTrackTintColor="blue"
        maximumTrackTintColor="green"
        thumbTintColor="#42faca"
      />

      <Text style={styles.resultado}>{valor.toFixed(0)}</Text>

      <Text style={styles.texto}>Brasileiro</Text>

      <Switch
        style={{ marginLeft: 10 }}
        value={status}
        onValueChange={(valorSwitch) => setStatus(valorSwitch)}
        thumbColor="green"
      />

      <Text
        style={{
          textAlign: 'left',
          fontSize: 16,
          color: 'green',
          marginLeft: 10,
          marginBottom: 20,
        }}>
        {status ? 'Sim' : 'Não'}
      </Text>

      <Button title="Confirmar" color="green" onPress={() => Confirmar()} />

      <Text style={styles.textoResult}>{result}</Text>
    </View>
  );
}
