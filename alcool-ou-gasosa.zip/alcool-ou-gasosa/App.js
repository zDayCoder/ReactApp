import React, { useState } from 'react';
import { Text, View, TouchableOpacity, TextInput, Image } from 'react-native';

import {styles} from './styles';

import { Card } from 'react-native-paper';

export default function App() {

const [result, setResult] = useState('');
  const [num1, setNum1] = useState(''); // Inicialize com string vazia
  const [num2, setNum2] = useState(''); // Inicialize com string vazia

  function calc() {
    const parsedNum1 = parseFloat(num1);
    const parsedNum2 = parseFloat(num2);
    let resultado = 0;

    if (isNaN(parsedNum1) || isNaN(parsedNum2) || num1 === '' || num2 === '') {
      setResult('Por favor, insira números válidos em ambos os campos.');
    } else {
      resultado = parsedNum1 / parsedNum2;
      if(resultado < 0.7){
        setResult('O derivado da cana-de-açúcar é o melhor para abastecer');
      }else if(resultado > 0.7){
        setResult('A gasolina é melhor');
      }else{
        setResult('Da no mesmo');
      }
     // alert('Diferença de preço: ' + resultado);
    }
  }


  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Álcool ou Gasosa
      </Text>

            <Image source={{ uri: 'https://www.terra.com.br/economia/infograficos/alcool-x-gasolina/img/gasolina.gif' }} style={styles.image} />

       <TextInput style={styles.input} placeholder="Preço do álcool" onChangeText={setNum1} />
       <TextInput style={styles.input} placeholder="Preço da gasolina" onChangeText={setNum2} />

      <Card style={{marginTop: 12, padding:2, background: "#e9e9e9", border: "2px solid #ccc"}}>
        <TouchableOpacity style={[styles.button, { backgroundColor: 'green'}]} onPress={() => calc()} >
          <Text style={styles.buttonText}>Verificar</Text>
        </TouchableOpacity>
      </Card>

      {result !== '' && (
      <Card style={{marginTop: 12, padding:8, background: "#e9e9e9", border: "2px solid #ccc"}}>
      <Text style={{ fontSize: 16}}>{result}</Text>
      </Card>
            )}


    </View>
  );
}
