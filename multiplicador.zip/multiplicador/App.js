import React, { useState } from 'react';
import { Text, View, TouchableOpacity, TextInput } from 'react-native';

import {styles} from './styles';

import { Card } from 'react-native-paper';

export default function App() {

const [result, setResult] = useState('');
const [num1, setNum1] = useState(0);
const [num2, setNum2] = useState(0);

function mult() {
  const parsedNum1 = parseFloat(num1);
    const parsedNum2 = parseFloat(num2);

    if (isNaN(parsedNum1) || isNaN(parsedNum2)) {
      setResult('Por favor, insira números válidos.');
    } else {
      setResult(parsedNum1 * parsedNum2);
    }
}


  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Multiplicador
      </Text>

       <TextInput style={styles.input} placeholder="Digite o primeiro número" onChangeText={setNum1} />
       <TextInput style={styles.input} placeholder="Digite o segundo número" onChangeText={setNum2} />

      <Card style={{marginTop: 12, padding:2, background: "#e9e9e9", border: "2px solid #ccc"}}>
        <TouchableOpacity style={[styles.button, { backgroundColor: 'green'}]} onPress={() => mult()} >
          <Text style={styles.buttonText}>Calcular</Text>
        </TouchableOpacity>
      </Card>
      {result !== '' && (

      <Card style={{marginTop: 12, padding:8, background: "#e9e9e9", border: "2px solid #ccc"}}>
      <Text style={{ fontSize: 16}}>{result}</Text>
      </Card>
            )}


    </View>
  );
}
