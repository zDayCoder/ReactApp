import React, { Component } from 'react';
import { View, Text, ScrollView, Image } from 'react-native';
import { styles } from './styles';
import myImage from './assets/snack-icon.png';


function App(){

  let img = 'https://aloalobahia.com/images/p/bkrebranding_alo_alo_bahia.png';
  let img1 = 'https://sme.goiania.go.gov.br/conexaoescola/wp-content/uploads/2020/10/mcdonalds-e1602870731296.png';
  let img2 = 'https://upload.wikimedia.org/wikipedia/commons/7/72/Logo_Giraffas.png';
  let img3 = 'https://www.bobs.com.br/static/images/og/og_main.png';
  let img4 = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-WtJ0XeqEg5_r35SN0EAwfhEUQztoYCj2QA&usqp=CAU';


  let texto = 'Burger King, muitas vezes abreviado como BK, é uma rede de restaurantes especializada em fast-food, fundada nos Estados Unidos por James McLamore e David Edgerton, que abriram a primeira unidade em Miami, Flórida.';
  let texto1 = 'McDonald s Corporation é uma rede multinacional estadunidense de fast food, fundada em 1940 como um restaurante operado por Richard e Maurice McDonald, em San Bernardino, Califórnia, Estados Unidos.';
  let texto2 = 'Giraffas é uma rede de fast-food brasileira, fundada no Lago Sul, no Distrito Federal em agosto de 1981 por dois amigos, os empresários Mauro Lacerda e Muniz Neto, com seu primeiro restaurante no comércio local da QI 09.';
  let texto3 = 'Bob s é uma rede brasileira de restaurantes foodservice fundada em 1952, pelo jogador de tênis estadunidense-brasileiro Robert Falkenburg, campeão do torneio de Wimbledon em 1948 e 1949.';
  let texto4 = 'Subway é uma rede norte-americana de restaurantes fast food, com especialidade em vendas de sanduíches e saladas. Foi fundada em 1965 por Fred De Luca e Peter Buck.';

  return(
    <View style={styles.container}>

      <Text style={styles.titulo}>Anúncios de Fast Food</Text>

      <ScrollView style={styles.backg} horizontal={true} showsHorizontalScrollIndicator={false}>
        <View style={styles.box1}>
        <Image
          source={{ uri: img }}
          style={{ width: 80, height: 80, alignSelf:'center', margin: 20}}
        />
        <Text style={styles.texto}>{texto}</Text>
        </View>
        <View style={styles.box2}>
        <Image
          source={{ uri: img1 }}
          style={{ width: 80, height: 80, alignSelf:'center', margin: 20}}
        />
        <Text style={styles.texto}>{texto1}</Text>
        </View>
        <View style={styles.box3}>
        <Image
          source={{ uri: img2 }}
          style={{ width: 80, height: 80, alignSelf:'center', margin: 20}}
        />
        <Text style={styles.texto}>{texto2}</Text>
        </View>
        <View style={styles.box1}>
        <Image
          source={{ uri: img3 }}
          style={{ width: 80, height: 80, alignSelf:'center', margin: 20}}
        />
        <Text style={styles.texto}>{texto3}</Text>
        </View>
        <View style={styles.box2}>
        <Image
          source={{ uri: img4 }}
          style={{ width: 80, height: 80, alignSelf:'center', margin: 20}}
        />
        <Text style={styles.texto}>{texto4}</Text>
        </View>
      </ScrollView>

    </View>
  )
}


export default App;