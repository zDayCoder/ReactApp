import {StyleSheet} from 'react-native'


const styles = StyleSheet.create({
  backg:{
    height: 5,
    width: 380,
    margin: 5,
    marginBottom: 300,
    borderWidth: 2,
    borderColor: '#777',
    borderRadius: 5,
    backgroundColor: '#fdd',
  },

  titulo:{
    fontSize: 20,
    color:'red',
    marginTop: 55,
    marginBottom: 25,
    textAlign: 'center',
  },
  
  texto:{
    fontSize: 12,
    color:'111',
    textAlign: 'justify',
    marginTop: 5,
    marginLeft: 10,
    padding: 10
  },

  container:{
    flex: 1
  },
  box1:{
    backgroundColor: '#eff',
    borderWidth: 2,
    borderColor: '#777',
    borderRadius: 5,
    height: 320,
    width: 200,
    margin: 20,
    marginRight: 5,
    marginLeft: 5
  },
  box2:{
    backgroundColor: '#eff',
    borderWidth: 2,
    borderColor: '#777',
    borderRadius: 5,
    height: 320,
    width: 200,
    margin: 20,
    marginRight: 5,
    marginLeft: 5
  },
  box3:{
    backgroundColor: '#eff',
    borderWidth: 2,
    borderColor: '#777',
    borderRadius: 5,
    height: 320,
    width: 200,
    margin: 20,
    marginRight: 5,
    marginLeft: 5
  }

})

export {styles}