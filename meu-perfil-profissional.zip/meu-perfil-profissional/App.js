import React from 'react';
import { Text, SafeAreaView, StyleSheet, Image } from 'react-native';

import { Card } from 'react-native-paper';

let name = "Ryan Figueiredo";
let age = "21 anos.";
let curse = "Ánalise e \ndesenvolvimento\nde sistemas";
let exp = "Back-end PHP";
let projects = "Procafeinação";


export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        WHOIS
      </Text>

      <Image source={require('./assets/zday.png')} style={styles.image} />

      <Card style={{marginTop: 12, padding:8, background: "#e9e9e9", border: "2px solid #ccc"}}>
      <Text style={{ fontSize: 16}}>Nome: {name}</Text>
      <Text style={{ fontSize: 16, marginTop:8}}>Idade: {age}</Text>
      </Card>

      <Card style={{marginTop: 12, padding:8, background: "#e9e9e9", border: "2px solid #ccc"}}>
      <Text style={{ fontSize: 16, marginTop:8}}>Cursando: {curse}</Text>
      <Text style={{ fontSize: 16, marginTop:8}}>Experiencia: {exp}</Text>
      <Text style={{ fontSize: 16, marginTop:8}}>Projetos: {projects}</Text>
      </Card>
      
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginTop: 24,
  },
  paragraph: {
    borderRadius: 12,
    margin: 24,
    fontSize: 28,
    padding:16,
    backgroundColor: "#202020",
    color: "#ff0000",
    fontWeight: 'bold',
    textAlign: 'center',
  },
  image: {
    borderRadius: 8,
    width: 100,
    height: 100,
  },
});
