import React, { useState } from 'react';
import { Text, View, TouchableOpacity, TextInput, Image } from 'react-native';

import {styles} from './styles';

import { Card } from 'react-native-paper';

export default function App() {
 
const [result, setResult] = useState('');
  const [peso, setPeso] = useState(''); // Inicialize com string vazia
  const [altura, setAltura] = useState(''); // Inicialize com string vazia

  function calc() {
    const parsedPeso = parseFloat(peso);
    const parsedAltura = parseFloat(altura);
    let resultado = 0;

    if (isNaN(parsedPeso) || isNaN(parsedAltura) || peso === '' || altura === '') {
      setResult('Por favor, insira números válidos em ambos os campos.');
    } else {


      //Calcular imc
      resultado = parsedPeso / (parsedAltura * parsedAltura);
      if(resultado < 18.5){
        setResult("Abaixo do Peso");
      }else if(resultado >= 18.5 && resultado < 25){
        setResult("Peso Normal");
      }else if(resultado >= 25 && resultado < 30){
        setResult("Sobrepeso");
      }else if(resultado >= 30 && resultado < 35){
        setResult("Obesidade Grau 1");
      }else if(resultado >= 35 && resultado < 40){
        setResult("Obesidade Grau 2");
      }else if(resultado >= 40){
        setResult("Obesidade Grau 3/Mórbida");
      }



     // alert('Diferença de preço: ' + resultado);
    }
  }


  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Calculadora de IMC
      </Text>

            <Image source={{ uri: 'https://play-lh.googleusercontent.com/ouL1lfSP_CyUgb5OUvI51jG3cevMfulA1GZGtS63r3Xfa8STYiIxq6KiY3PkMc6PcTk' }} style={styles.image} />
       <TextInput style={[styles.input,{marginTop:62}]} placeholder="Peso ex.: 87" onChangeText={setPeso} />
       <TextInput style={styles.input} placeholder="Altura ex.: 1.80" onChangeText={setAltura} />

        <TouchableOpacity style={[styles.button, { marginTop:24, borderRadius:4, padding:8,backgroundColor: 'green'}]} onPress={() => calc()} >
          <Text style={styles.buttonText}>Calcular IMC</Text>
        </TouchableOpacity>

      {result !== '' && (
      <Card style={{marginTop: 12, padding:8, background: "#e9e9e9", border: "2px solid #ccc"}}>
      <Text style={{ fontSize: 16}}>{result}</Text>
      </Card>
            )}


    </View>
  );
}
