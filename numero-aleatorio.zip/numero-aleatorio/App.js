import React, { useState } from 'react';
import { Text, View, TouchableOpacity, TextInput, Image } from 'react-native';

import {styles} from './styles';

import { Card } from 'react-native-paper';

export default function App() {

const [result, setResult] = useState('');
  

  function calc() {
    setResult(Math.floor(Math.random() * 11));
  }


  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Número aleatório
      </Text>

            <Image source={{ uri: 'https://pm1.aminoapps.com/6336/19d64bba1ca25896c05582c2f9d92635fd8b20ae_00.jpg' }} style={styles.image} />
       
       <Text style={[styles.paragraph, {color:'red', backgroundColor: 'transparent'}]}>
        Pense em um número
      </Text>
      
{result !== '' && (
      <Card style={{marginTop: 12, padding:8, background: "#e9e9e9", border: "2px solid #ccc"}}>
      <Text style={{ fontSize: 16}}>{result}</Text>
      </Card>
            )}

        <TouchableOpacity style={[styles.button, { marginTop:24, borderRadius:4, padding:8,backgroundColor: 'green'}]} onPress={() => calc()} >
          <Text style={styles.buttonText}>Gerar Número</Text>
        </TouchableOpacity>

      


    </View>
  );
}
