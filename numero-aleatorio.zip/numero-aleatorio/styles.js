
const styles = ({
  container: {
    alignItems: 'center',
  },
  paragraph: {
    borderRadius:4,
    margin: 14,
    fontSize: 18,
    width: '90%',
    padding:16,
    backgroundColor: "#202020",
    color: "#ffff00",
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonText: {
    textTransform: 'uppercase',
    padding: 8,
    textAlign: 'center',
    color: 'white',
    fontWeight: '600',
  },
  input:{
    height: 45,
    borderWidth: 1,
    borderColor: '#222',
    margin: 10,
    fontSize: 20,
    padding: 10,
  },
  image: {
    borderRadius: 8,
    width: 120,
    height: 100,
  },
});

export {styles};